## Module <pos_order_line_image>

#### 30.11.2020
#### Version 14.0.1.0.0
#### Migration
Migration Of Pos Order Line Product Image



