## Module <pos_multi_variant>

#### 21.08.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit for pos_multi_variant

#### 20.09.2019
#### Version 12.0.1.0.1
##### FIX
- Bug Fixed.
