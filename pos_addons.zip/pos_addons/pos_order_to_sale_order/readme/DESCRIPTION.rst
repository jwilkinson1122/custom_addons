This module extends the functionality of point of sale to allow sale orders
creation from the Point of Sale.

In the POS UI, button has been added to create a sale order and discard
the current POS order.

This module is usefull in many cases, for exemple :

* take orders with a very simple interface

* if you have some customers that come every day in your shop, but want to
  have a unique invoice at the end of the month. With that module, you can
  create a sale order and deliver products every time to keep your stock value
  correct, and to create a unique invoice, when you want.

**Technical Notes**

* Some hooks are defined in the JS file, to define custom behaviour after
  having created the sale order.

* Some prepare functions are available in the ``sale.order`` model and
  ``sale.order.line`` models to overload the creation of the sale order.
