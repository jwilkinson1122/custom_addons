# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import pos_box
from . import pos_details
from . import pos_payment
from . import pos_close_session_wizard
