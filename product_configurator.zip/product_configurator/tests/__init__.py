from . import test_product_configurator_test_cases

# from . import test_create
# from . import test_configuration_rules
from . import test_product

# from . import test_product_attribute
# from . import test_product_config
# from . import test_wizard
