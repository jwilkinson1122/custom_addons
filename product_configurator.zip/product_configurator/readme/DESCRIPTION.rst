This module has all the mechanics to support product configuration. It serves as a base
dependency for configuration interfaces.
