from . import product_config
from . import product_attribute
from . import product
from . import ir_ui_view
