Product Configurator wizard available on Sales Orders.
